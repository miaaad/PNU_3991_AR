package com.neshan.task1.domain.executor;


import java.util.concurrent.Executor;

public interface ThreadExecutor extends Executor {
}